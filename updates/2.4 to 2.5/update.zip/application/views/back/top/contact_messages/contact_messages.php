<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?=$title?></title>
<!--STYLESHEET-->
<!--=================================================-->
<!--Open Sans Font [ OPTIONAL ]-->
<!-- <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'> -->
<!--Bootstrap Stylesheet [ REQUIRED ]-->
<link href="<?=base_url()?>template/back/css/bootstrap.min.css" rel="stylesheet">
<!--Nifty Stylesheet [ REQUIRED ]-->
<link href="<?=base_url()?>template/back/css/nifty.min.css" rel="stylesheet">
<link href="<?=base_url()?>template/back/css/theme-dark.css" rel="stylesheet">
<!--Nifty Premium Icon [ DEMONSTRATION ]-->
<link href="<?=base_url()?>template/back/css/demo/nifty-demo-icons.min.css" rel="stylesheet">
<!--Demo [ DEMONSTRATION ]-->
<link href="<?=base_url()?>template/back/css/demo/nifty-demo.min.css" rel="stylesheet">
<!--Premium Solid Icons [ OPTIONAL ]-->
<link href="<?=base_url()?>template/back/premium/icon-sets/icons/solid-icons/premium-solid-icons.css" rel="stylesheet">
<!--Font Awesome [ OPTIONAL ]-->
<link href="<?=base_url()?>template/back/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<!--Animate.css [ OPTIONAL ]-->
<link href="<?=base_url()?>template/back/plugins/animate-css/animate.min.css" rel="stylesheet">
<!--Text Editor [ OPTIONAL ]-->
<link href="<?=base_url()?>template/back/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet">
